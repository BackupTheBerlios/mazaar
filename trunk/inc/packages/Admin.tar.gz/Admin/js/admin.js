/* ***** BEGIN LICENSE BLOCK *****
 * Licensed under Version: MPL 1.1/GPL 2.0/LGPL 2.1
 * Full Terms at http://mozile.mozdev.org/license.html
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is MazaarRemote.
 *
 * The Initial Developer of the Original Code is Ondrej Donek
 * Portions created by the Initial Developer are Copyright (C) 2004-2005
 * the Initial Developer. All Rights Reserved.
 *
 * Contributor(s):
 *
 * ***** END LICENSE BLOCK ***** */ 

/**
 * @file          admin/js/admins.js
 * @package       MazaarRemote
 * @version       0.1
 * @created       1.5.2005
 * @revisited     1.5.2005
 * @author        Ondrej Donek
 * @description   Main JavaScript file of Mazaar web administration center.
 */


var login = false;
var u_id = null;
var u_pass = null;


/**
 * Pri startu aplikace.
 */
function startUp( _login )
{
  if(_login) {
    checkPrivileges();
    login = true;
  }
} // end startUp();


// *******************************************
 

/**
 * Zobrazi danou stranku.
 *
 * @param   string   Jmeno stranky.
 */
function show( page ){
  // vymyslet jak zaroven i moci predat username a userpass
  // nejakou bezpecnou metodou. COOKIES?
  document.location = "admin.php?pg="+page;
} // end show( page )