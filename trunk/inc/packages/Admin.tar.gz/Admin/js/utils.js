/* ***** BEGIN LICENSE BLOCK *****
 * Licensed under Version: MPL 1.1/GPL 2.0/LGPL 2.1
 * Full Terms at http://mozile.mozdev.org/license.html
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is MazaarRemote.
 *
 * The Initial Developer of the Original Code is Ondrej Donek
 * Portions created by the Initial Developer are Copyright (C) 2004-2005
 * the Initial Developer. All Rights Reserved.
 *
 * Contributor(s):
 *
 * ***** END LICENSE BLOCK ***** */ 

// @file          admin/js/utils.js
// @package       MazaarRemote
// @version       0.1
// @created       1.5.2005
// @revisited     1.5.2005
// @author        Ondrej Donek
// @description   Main file of Mazaar web administration center.

// @todo Zjistit na zacatku zda je pritomna Mozilla a pripadne zobrazit chybovou stranku.
// @todo Prihlasovaci stranka.
// @todo Chybova stranka.
// @todo Chybova stranka.
 


/**
 * Zobrazi danou stranku.
 *
 * @param   string   Jmeno stranky.
 */
function show( page ){
  // vymyslet jak zaroven i moci predat username a userpass
  // nejakou bezpecnou metodou. COOKIES?
  document.location = "admin.php?pg="+page;
} // end show( page )
 
 

/**
 * Inicializacni funkce. Potrebna ziskani potrebnych povoleni.
 */
function checkPrivileges()
{
	try 
  { 
		netscape.security.PrivilegeManager.enablePrivilege("UniversalXPConnect");
		// netscape.security.PrivilegeManager.enablePrivilege("UniversalBrowserRead");
		// netscape.security.PrivilegeManager.enablePrivilege("UniversalBrowserWrite");
	} 
  catch(e) 
  {
		alert('Permission denied.'); 
	}
} // end checkPrivileges()
 


/**
 * Zobrazi dane URL v novem okne.
 *
 * @param   string   URL, ktere chceme zobrazit.
 */
function launchExternalUrl( url ) 
{
	try 
  {
    var extProtocolSvc=Components.classes["@mozilla.org/uriloader/external-protocol-service;1"].getService(Components.interfaces.nsIExternalProtocolService);
	  var ioService=Components.classes["@mozilla.org/network/io-service;1"].getService(Components.interfaces.nsIIOService);
	  var uri=ioService.newURI(url, null, null);
	  extProtocolSvc.loadUrl(uri);
  }
  catch(e)
  {
    dump(e);
  }
} // end launchExternalUrl( url )



/** 
 * Nacteni externiho skriptu.
 *
 * @param   string   Cesta k souboru s javascriptem.
 *
 * @return boolean Vraci true pokud vse probehlo v poradku.
 */
function loadExternalJS( path ) {
  try 
  {
    var loader = Components.classes["@mozilla.org/moz/jssubscript-loader;1"];
    loader = loader.getService( mozIJSSubScriptLoader );
    loader.loadSubScript( path, window );
    return true;
  }
  catch(e) 
  { 
    dump(e); 
    return false;
  }
} // end loadExternalJS( path );