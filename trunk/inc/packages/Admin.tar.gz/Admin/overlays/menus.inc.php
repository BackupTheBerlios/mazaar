<?php
// Defaultni stranky

// 1. Nastaveni
// 2. Administratori
// 3. Logout

$m_item = Array();

$m_item[0] = Array( 'name' => 'prefs',
                    'title' => 'Nastavení',
                    'description' => 'Nastavení serveru.',
                    'disabled' => false );

$m_item[1] = Array( 'name' => 'admins',
                    'title' => 'Administrátoři',
                    'description' => 'Administrátoři.',
                    'disabled' => false );

$m_item[2] = Array( 'name' => 'logout',
                    'title' => 'Odhlášení',
                    'description' => 'Odhlášení z admin.centra.',
                    'disabled' => false );

?>