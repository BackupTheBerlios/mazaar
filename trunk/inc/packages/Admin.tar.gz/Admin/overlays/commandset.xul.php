<script type="application/x-javascript">
<![CDATA[

function openPage( page )
{
  if( page == 'logout' ) {
    document.location = 'admin.php';
  }
  else {
    document.location = document.location+'&pg='+page+'.xul.php'; 
  }
}

]]>
</script>
  
  
<!-- commandset -->
<commandset id="workspace-commandset">
<?php
  foreach( $m_item as $cmd ) {
    echo '<command id="cmd:'.$cmd['name'].'" oncommand="openPage(\''.$cmd['name'].'\');"/>'.EOL;
  }  
?>
</commandset>