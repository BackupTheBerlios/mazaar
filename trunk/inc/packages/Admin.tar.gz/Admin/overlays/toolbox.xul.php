<toolbox id="workspace-toolbox">  
<toolbar>
<?php
  foreach( $m_item as $cmd ) {
    echo '<toolbarbutton id="tbtn-' . $cmd['name'] . '" '.
         'label="'.$cmd['title'].'" '. 
         'tooltiptext="'.$cmd['description'].'" '.  
         'oncommand="openPage(\''.$cmd['name'].'\');" '.
         'image="admin/icons/'.$cmd['name'].'.gif"/>'.EOL;
  }  
?>
</toolbar>
</toolbox>