<!--
   - We have to load all XML config. files and allow to users 
   - modify them.
   -->

<script type="application/x-javascript">
<![CDATA[

function showConfigFile( file )
{
  document.location = document.location+'&fl='+file;  
}

]]>
</script>



<groupbox>
  <caption label="Vyber konfig. soubor" class="blue"/>
  <menulist id="filelist" oncommand="showConfigFile(this.selectedItem.label);">
    <menupopup>
      <menuitem label="inc/mazaar/mazaar.config.xml"/>
      <menuitem label="inc/mazaar/user.config.xml" selected="true"/>
      <menuitem label="admin/admin.config.xml"/>
    </menupopup>
  </menulist>
</groupbox>

<groupbox>
  <caption label="Nastavení daného souboru:" class="blue"/>
  <grid flex="1">
    <columns>
      <column flex="1"/>
      <column flex="2"/>
    </columns>
    <rows>
<?php
if( isset( $fl ) ) {
  if( @file_exists($fl) ) {
    $xml = @simplexml_load_file($fl);
    foreach ($xml->children() as $pref) {
      $key = $val = '';
      foreach( $pref->attributes() as $at_name => $at_val ) {
          if( $at_name == 'name' ) $name = strval($at_val);
          if( $at_name == 'description' ) $desc = strval($at_val);
          if( $at_name == 'value' ) $val = strval($at_val);
      }
?>
      <row style="border:">
        <description><label class="strong" value="<?php echo $name; ?>"/> <?php echo $desc; ?></description>
        <textbox id="" value="<?php echo $val; ?>" flex="1"/>
      </row>
<?php
    }
  }
}
else {
?>
      <row>
        <spacer flex="1"/>
        <description>Nevybrali jste žádný konfigruační soubor.</description>
      </row>
<?php
}
?>
    </rows>
  </grid>
</groupbox>