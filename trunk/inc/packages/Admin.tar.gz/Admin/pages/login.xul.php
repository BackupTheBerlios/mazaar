<script type="application/x-javascript" src="admin/js/md5.js"/>

<vbox flex="1" align="center" pack="center">
  <groupbox>
    <caption label="Přihlášení" class="blue"/>
    <grid>
      <rows>
        <row>
          <label class="strong" control="username">Uživ. jméno:</label>
          <textbox id="username" value=""/>
        </row>
        <row>
          <label class="strong" control="userpass">Heslo:</label>
          <textbox id="userpass" value="" type="password"/>
        </row>
        <row>
          <spacer/>
          <checkbox id="remember" label="Pamatovat heslo?" checked="false"/>
        </row>
        <row>
          <button id="cancel" label="Zruš" oncommand="cancelLogin();"/>
          <button id="submit" label="Odešli" oncommand="submitLogin();"/>
        </row>
      </rows>
    </grid>
  </groupbox>
</vbox>

<script type="application/x-javascript">
<![CDATA[

// potvrdi prihlasovaci formular
function submitLogin()
{
  var username = document.getElementById('username').value;
  var userpass = document.getElementById('userpass').value;
  var remember = document.getElementById('remember').checked;
  
  document.location = 'admin.php?u_name=' + username + 
                      '&u_pass=' + hex_md5(userpass) + 
                      '&remember=' + remember;
} // end submitLogin();


// vymaze prihlasovaci formular
function cancelLogin()
{
  document.getElementById('username').value='';
  document.getElementById('userpass').value='';
} // end cancelLogin();

]]>
</script>