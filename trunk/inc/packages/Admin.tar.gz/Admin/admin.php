﻿<?php
/* ***** BEGIN LICENSE BLOCK *****
 * Licensed under Version: MPL 1.1/GPL 2.0/LGPL 2.1
 * Full Terms at http://mozile.mozdev.org/license.html
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is MazaarRemote.
 *
 * The Initial Developer of the Original Code is Ondrej Donek
 * Portions created by the Initial Developer are Copyright (C) 2004-2005
 * the Initial Developer. All Rights Reserved.
 *
 * Contributor(s):
 *
 * ***** END LICENSE BLOCK ***** */ 

/**
 * @file          admin.php
 * @package       MazaarRemote
 * @version       0.1
 * @created       1.5.2005
 * @revisited     1.5.2005
 * @author        Ondrej Donek
 * @description   Main file of Mazaar web administration center.
 * @todo          Zjistit na zacatku zda je pritomna Mozilla 
 *                a pripadne zobrazit chybovou stranku.
 * @todo Prihlasovaci stranka.
 * @todo Chybova stranka.
 * @todo Chybova stranka.
 */


require 'inc/mazaar/init.inc.php';

header( "Content-Type: application/vnd.mozilla.xul+xml;charset=UTF-8 \r\n" );
echo '<?xml version="1.0" encoding="utf-8"?>'.EOL;
echo '<?xml-stylesheet href="chrome://global/skin" type="text/css"?>'.EOL;
echo '<?xml-stylesheet href="admin/admin.css" type="text/css"?>'.EOL;


// nacteme dodatecne nastaveni pro admin.centrum
$prefs->LoadFile( 'admin/admin.config.xml' );
$db = new DB();

$login = false;


if((!isset($u_name) || !isset($u_id)) && !isset($u_pass)) 
{
  // uzivatel jeste nic nezaslal, zobrazime login
  $pg = $prefs->admin_default_login_page;
}
else 
{
  // uzivatel uz zaslal prihlasovaci informace  
  if(isset($u_id)) {
    $query =  "SELECT `group` FROM `".$prefs->sql_prefix."admins` WHERE ".
              "`ID`='".$u_id."' AND `pass`='".$u_pass."' LIMIT 1 ";
  } else {
    $query = "SELECT `group` FROM `".$prefs->sql_prefix."admins` WHERE ".
             "`username`='".$u_name."' AND `pass`='".$u_pass."' LIMIT 1 ";
  }
  // echo $query;
  $db->query( $query );
                
  if($db->rows != 1)  
  {
    // prihlaseni nebylo uspesne, zobrazime login
    $pg = $prefs->admin_default_login_page;
  } 
  else 
  {
    // prihlaseni bylo uspesne
    if(!isset($pg)) {
      // pokud nebyla vybrana stranka, zobrazime defaultni
      $pg = $prefs->admin_default_page;
    }
    
    // ulozit heslo
    if( $remember == true ) {
      // zpracovat ukladani hesla (budto pres session 
      // nebo pres cookies)
    }    
    
    $login = true;
  }
}
?>

<window id="mazaarRemote:workspace" title="Mazaar" 
        orient="vertical" onload="startUp(<?php echo $login;?>);"
        xmlns:html="http://www.w3.org/1999/xhtml" 
        xmlns="http://www.mozilla.org/keymaster/gatekeeper/there.is.only.xul">
		

<script type="application/x-javascript" src="admin/js/utils.js"/>
<script type="application/x-javascript" src="admin/js/admin.js"/>
<script type="application/x-javascript">
alert( "Login: <?php echo $login;?>" );
alert( "Page: <?php echo $pg;?>" );
</script>


<?php
if( @file_exists( 'admin/pages/'.$pg ) && $pg!='') {
  if( $login == true ) {
    include 'admin/overlays/menus.inc.php';
    //$xul = new Xul();
    //$xul->commandset( $commands );
    include 'admin/overlays/commandset.xul.php';
    // $menus -> array s polozkama menu
    // $xul->menubar( $menus );
    // $xul->toolbox( $toolbox );
    include 'admin/overlays/toolbox.xul.php';
  }
  include 'admin/pages/'.$pg;
}
else {
  @include 'admin/pages/error.xul.php';
}
?>


</window>